import path from "path";
import { fileURLToPath } from "url";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "src") },
  },
  build: {
    target: ["es2020", "chrome95", "firefox91", "safari14"],
    minify: "esbuild",
    cssMinify: true,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor:    ["react", "react-dom"],
          crossmint: ["@crossmint/client-sdk-react-ui"],
        },
      },
    },
    chunkSizeWarningLimit: 1200,
  },
});
